package com.example.submission_restaurant_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
