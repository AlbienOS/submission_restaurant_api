import 'package:flutter/material.dart';

final Color primaryColor = Color(0xFFFFFFFF);
final Color secondColor = Color(0xFFFF449F);

//https://www.youtube.com/watch?v=qQ75cxc5q8o
//https://github.com/abuanwar072/Meditation-App/blob/master/lib/main.dart

